package BookMyShow.Enums;

public enum SeatStatus {
    FREE,
    RESERVED,
    BOOKED
}
