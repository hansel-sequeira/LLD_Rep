package BookMyShow.Enums;

public enum Genre {
    COMEDY,
    HORROR,
    THRILLER
}
