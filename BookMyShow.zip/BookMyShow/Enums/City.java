package BookMyShow.Enums;

public enum City {
    DELHI,
    BENGALURU
}
