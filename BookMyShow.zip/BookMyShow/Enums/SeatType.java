package BookMyShow.Enums;

public enum SeatType {
    STANDARD,
    RECLINE
}
