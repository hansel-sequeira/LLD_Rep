package BookMyShow.Entitites;

public class Customer {
    String name;
    public Customer(String name) {
        this.name = name;
    }
}
